﻿using KafkaDemo.Core.Domain;
using KafkaDemo.Core.Events;
using Raven.Client.Documents;
using Raven.Client.Documents.Session;

namespace AddUser.Infrastructure.Repositories
{
    public class EventStoreRepository : IEventStoreRepository
    {
        private readonly IAsyncDocumentSession _asyncSession;

        public EventStoreRepository(IAsyncDocumentSession asyncSession)
        {
            _asyncSession = asyncSession;
        }

        public async Task<List<EventModel>> FindAllAsync()
        {
            return await _asyncSession.Query<EventModel>().ToListAsync().ConfigureAwait(false);
        }

        public async Task<List<EventModel>> FindByAggregateId(Guid aggregateId)
        {
            return await _asyncSession.Query<EventModel>()
            .Where(x => x.AggregateIdentifier == aggregateId).ToListAsync().ConfigureAwait(false);
        }

        public async Task SaveAsync(EventModel @event)
        {
            await _asyncSession.StoreAsync(@event).ConfigureAwait(false);
            await _asyncSession.SaveChangesAsync().ConfigureAwait(false);
        }
    }
}
