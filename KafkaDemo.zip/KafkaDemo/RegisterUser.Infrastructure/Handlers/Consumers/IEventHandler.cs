﻿using RegisterUser.Domain.Events;

namespace RegisterUser.Infrastructure.Handlers.Consumers
{
    public interface IEventHandler
    {
        void On(NewAuthUserAddedEvent @event);
    }
}
