﻿using KafkaDemo.Core.Events;

namespace KafkaDemo.Core.Infrastructure
{
    public interface IEventStore
    {
        Task SaveEventsAsync(Guid aggregateId, IEnumerable<BaseEvent> events, int expectedVersion, string topic);
        //Task<List<BaseEvent>> GetEventsAsync(Guid aggregateId);
        //Task<List<Guid>> GetAggregateIdsAsync();
    }
}
