﻿using Microsoft.Extensions.Logging;
using RegisterUser.Domain.Events;

namespace RegisterUser.Infrastructure.Handlers.Consumers
{
    public class EventHandler : IEventHandler
    {
        private readonly ILogger<EventHandler> _logger;

        public EventHandler(ILogger<EventHandler> logger)
        {
            _logger = logger;
        }

        public void On(NewAuthUserAddedEvent @event)
        {
            _logger.LogInformation($"Register Kafka service consumed {nameof(NewAuthUserAddedEvent)} event, User Id: {@event.UserId}");
        }
    }
}
