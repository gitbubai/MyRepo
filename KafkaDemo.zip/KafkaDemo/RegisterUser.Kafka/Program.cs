using Confluent.Kafka;
using KafkaDemo.Core.Consumers;
using RegisterUser.Infrastructure.Consumers;
using RegisterUser.Infrastructure.Handlers.Consumers;
using RegisterUser.Kafka;
using EventHandler = RegisterUser.Infrastructure.Handlers.Consumers.EventHandler;

IHost host = Host.CreateDefaultBuilder(args)
    .UseSystemd()
    .UseWindowsService()
    .ConfigureServices((context,services) =>
    {
        services.Configure<ConsumerConfig>(context.Configuration.GetSection(nameof(ConsumerConfig)));
        services.AddScoped<IEventHandler, EventHandler>();
        services.AddScoped<IEventConsumer, EventConsumer>();
        services.AddHostedService<ConsumerHostedService>();
    })
    .Build();

await host.RunAsync();
