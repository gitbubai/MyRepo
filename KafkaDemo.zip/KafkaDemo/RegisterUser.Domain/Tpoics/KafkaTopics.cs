﻿namespace RegisterUser.Domain.Tpoics
{
    public class KafkaTopics
    {
        public const string TheDomainTopic = "Demo.Domain";
        public const string TheAuthTopic = "Demo.Auth";
    }
}
