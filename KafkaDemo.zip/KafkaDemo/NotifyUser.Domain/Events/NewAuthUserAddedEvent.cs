﻿using KafkaDemo.Core.Events;

namespace NotifyUser.Domain.Events
{
    public class NewAuthUserAddedEvent : BaseEvent
    {
        public NewAuthUserAddedEvent() : base(nameof(NewAuthUserAddedEvent))
        {
        }

        public string AuthId { get; set; }
        public string UserId { get; set; }
    }
}
