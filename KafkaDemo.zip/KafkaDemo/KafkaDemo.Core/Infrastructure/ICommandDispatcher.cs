﻿using KafkaDemo.Core.Commands;

namespace KafkaDemo.Core.Infrastructure
{
    public interface ICommandDispatcher
    {
        void RegisterHandler<T>(Func<T, string, Task> handler) where T : BaseCommand;
        Task SendAsync(BaseCommand command, string topic);
    }
}
