﻿using AddUser.Domain.Events;
using KafkaDemo.Core.Domain;

namespace AddUser.Domain.Aggregates
{
    public class AddUserAggregate : AggregateRoot
    {
        private bool _active;
        private string _name;
        private readonly Dictionary<Guid, Tuple<string, string>> _comments = new();

        public bool Active { get => _active; set => _active = value; }

        public AddUserAggregate()
        {
        }

        public void NewUserAdded(Guid id, string name, string email, string userid)
        {
            RaiseEvent(new NewUserAddedEvent
            {
                Id = id,
                Name = name,
                Email = email,
                UserId = userid,
                DatePosted = DateTime.Now
            });
        }

        public void Apply(NewUserAddedEvent @event)
        {
            _id = @event.Id;
            _active = true;
            _name = @event.Name;
        }

        public void NewAuthUserAdded(Guid id, string authid, string userid, string name, string email)
        {
            RaiseEvent(new NewAuthUserAddedEvent
            {
                Id = id,
                AuthId= authid,
                UserId = userid,
                Name = name,
                Email = email,               
                DatePosted = DateTime.Now
            });
        }

        public void Apply(NewAuthUserAddedEvent @event)
        {
            _id = @event.Id;
            _active = true;
            _name = @event.Name;
        }
    }
}
