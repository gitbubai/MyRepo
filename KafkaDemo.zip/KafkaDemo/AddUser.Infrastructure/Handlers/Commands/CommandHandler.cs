﻿using AddUser.Domain.Aggregates;
using AddUser.Domain.Commands;
using KafkaDemo.Core.Handlers;

namespace AddUser.Infrastructure.Handlers.Commands
{
    public class CommandHandler : ICommandHandler
    {
        private readonly IEventSourcingHandler<AddUserAggregate> _eventSourcingHandler;

        public CommandHandler(IEventSourcingHandler<AddUserAggregate> eventSourcingHandler)
        {
            _eventSourcingHandler = eventSourcingHandler;
        }

        //registerd inside program.cs
        public async Task HandleAsync(NewUserAddedCommand command,string topic)
        {
            Random generator = new Random();
            String uid = "U-"+generator.Next(0, 1000000).ToString("D6");
            var aggregate = new AddUserAggregate();
            aggregate.NewUserAdded(command.Id, command.Name, command.Email, uid);
            await _eventSourcingHandler.SaveAsync(aggregate,topic);
        }

        public async Task HandleAsync(NewAuthUserAddedCommand command, string topic)
        {
            var aggregate = new AddUserAggregate();
            Random generator = new Random();
            command.AuthId = "A-" + generator.Next(0, 1000000).ToString("D6");
            aggregate.NewAuthUserAdded(command.Id, command.AuthId, command.UserId, command.Name, command.Email);
            await _eventSourcingHandler.SaveAsync(aggregate, topic);
        }
    }
}
