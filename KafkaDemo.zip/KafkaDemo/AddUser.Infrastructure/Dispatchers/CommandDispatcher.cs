﻿using KafkaDemo.Core.Commands;
using KafkaDemo.Core.Infrastructure;
using System.Runtime.CompilerServices;

namespace AddUser.Infrastructure.Dispatchers
{
    public class CommandDispatcher : ICommandDispatcher
    {
        //this list is populated from program.cs and contanains handler(HandleAsync)
        private readonly Dictionary<Type, Func<BaseCommand, string, Task>> _handlers = new();

        //called from program.cs
        public void RegisterHandler<T>(Func<T, string, Task> handler) where T : BaseCommand
        {
            if (_handlers.ContainsKey(typeof(T)))
            {
                throw new IndexOutOfRangeException("You cannot register the same command handler twice!");
            }

            _handlers.Add(typeof(T), (x,y) => handler((T)x, y));
        }

        //called from controller
        public async Task SendAsync(BaseCommand command, string topic)
        {
            if (_handlers.TryGetValue(command.GetType(), out Func<BaseCommand, string, Task> handler))
            {
                await handler(command, topic);
            }
            else
            {
                throw new ArgumentNullException(nameof(handler), "No command handler was registered!");
            }
        }
    }
}
