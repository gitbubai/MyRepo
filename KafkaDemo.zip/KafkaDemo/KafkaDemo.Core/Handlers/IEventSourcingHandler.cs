﻿using KafkaDemo.Core.Domain;

namespace KafkaDemo.Core.Handlers
{
    public interface IEventSourcingHandler<T>
    {
        Task SaveAsync(AggregateRoot aggregate, string topic);
        //Task<T> GetByIdAsync(Guid aggregateId);
        //Task RepublishEventsAsync();
    }
}
