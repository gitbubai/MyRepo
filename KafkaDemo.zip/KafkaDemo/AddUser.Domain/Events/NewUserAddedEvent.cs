﻿using KafkaDemo.Core.Events;

namespace AddUser.Domain.Events
{
    public class NewUserAddedEvent : BaseEvent
    {
        public NewUserAddedEvent() : base(nameof(NewUserAddedEvent))
        {
        }

        public string Name { get; set; }
        public string UserId { get; set; }
        public string Email { get; set; }
        public DateTime DatePosted { get; set; }
    }
}
