﻿using KafkaDemo.Core.Commands;

namespace AddUser.Domain.Commands
{
    public class NewAuthUserAddedCommand : BaseCommand
    {
        public string AuthId { get; set; }
        public string UserId { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
    }
}
