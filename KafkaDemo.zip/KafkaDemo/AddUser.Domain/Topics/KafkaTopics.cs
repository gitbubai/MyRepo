﻿namespace AddUser.Domain.Topics
{
    public class KafkaTopics
    {
        public const string TheDomainTopic = "Demo.Domain";
        public const string TheAuthTopic = "Demo.Auth";
    }
}
