﻿using AddUser.Domain.Events;

namespace AddUser.Infrastructure.Handlers.Consumers
{
    public interface IEventHandler
    {
        Task On(NewUserAddedEvent @event);
    }
}
