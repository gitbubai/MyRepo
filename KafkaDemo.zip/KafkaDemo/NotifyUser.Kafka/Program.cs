using Confluent.Kafka;
using KafkaDemo.Core.Consumers;
using NotifyUser.Infrastructure.Consumers;
using NotifyUser.Infrastructure.Handlers.Consumers;
using NotifyUser.Kafka;
using EventHandler = NotifyUser.Infrastructure.Handlers.Consumers.EventHandler;

IHost host = Host.CreateDefaultBuilder(args)
    .UseSystemd()
    .UseWindowsService()
    .ConfigureServices((context,services) =>
    {
        services.Configure<ConsumerConfig>(context.Configuration.GetSection(nameof(ConsumerConfig)));
        services.AddScoped<IEventHandler, EventHandler>();
        services.AddScoped<IEventConsumer, EventConsumer>();
        services.AddHostedService<ConsumerHostedService>();
    })
    .Build();

await host.RunAsync();
