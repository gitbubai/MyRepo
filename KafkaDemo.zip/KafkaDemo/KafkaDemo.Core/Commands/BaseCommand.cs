﻿using KafkaDemo.Core.Messages;

namespace KafkaDemo.Core.Commands
{
    public abstract class BaseCommand : Message
    {

    }
}
