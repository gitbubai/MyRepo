﻿using KafkaDemo.Core.Events;

namespace RegisterUser.Domain.Events
{
    public class NewAuthUserAddedEvent : BaseEvent
    {
        public NewAuthUserAddedEvent() : base(nameof(NewAuthUserAddedEvent))
        {
        }

        public string AuthId { get; set; }
        public string UserId { get; set; }
    }
}
