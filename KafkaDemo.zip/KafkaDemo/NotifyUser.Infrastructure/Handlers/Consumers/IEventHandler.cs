﻿using NotifyUser.Domain.Events;

namespace NotifyUser.Infrastructure.Handlers.Consumers
{
    public interface IEventHandler
    {
        void On(NewAuthUserAddedEvent @event);
    }
}
