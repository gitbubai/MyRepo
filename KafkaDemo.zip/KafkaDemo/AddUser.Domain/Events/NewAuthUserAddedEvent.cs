﻿using KafkaDemo.Core.Events;

namespace AddUser.Domain.Events
{
    public class NewAuthUserAddedEvent : BaseEvent
    {
        public NewAuthUserAddedEvent() : base(nameof(NewAuthUserAddedEvent))
        {

        }
        public string AuthId { get; set; }
        public string UserId { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }       
        public DateTime DatePosted { get; set; }
    }
}
