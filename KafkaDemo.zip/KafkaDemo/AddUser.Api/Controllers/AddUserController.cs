﻿using AddUser.Domain.Commands;
using AddUser.Domain.Topics;
using KafkaDemo.Core.Infrastructure;
using Microsoft.AspNetCore.Mvc;

namespace AddUser.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AddUserController : ControllerBase
    {
        private readonly ILogger<AddUserController> _logger;
        private readonly ICommandDispatcher _commandDispatcher;

        public AddUserController(ILogger<AddUserController> logger, ICommandDispatcher commandDispatcher)
        {
            _logger = logger;
            _commandDispatcher = commandDispatcher;
        }

        [HttpPost]
        public async Task<ActionResult> NewPostAsync(NewUserAddedCommand command)
        {
            var id = Guid.NewGuid();
            try
            {
                command.Id = id;
                await _commandDispatcher.SendAsync(command, KafkaTopics.TheDomainTopic);

                return StatusCode(StatusCodes.Status201Created);
            }
            catch (InvalidOperationException ex)
            {
                _logger.Log(LogLevel.Warning, ex, "Client made a bad request!");
                return BadRequest();
            }
            catch (Exception ex)
            {
                const string SAFE_ERROR_MESSAGE = "Error while processing request to create a new post!";
                _logger.Log(LogLevel.Error, ex, SAFE_ERROR_MESSAGE);

                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

    }
}
