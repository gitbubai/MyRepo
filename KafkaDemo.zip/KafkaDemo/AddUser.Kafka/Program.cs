using AddUser.Domain.Aggregates;
using AddUser.Domain.Commands;
using AddUser.Domain.Topics;
using AddUser.Infrastructure.Consumers;
using AddUser.Infrastructure.Dispatchers;
using AddUser.Infrastructure.Handlers.Commands;
using AddUser.Infrastructure.Handlers.Consumers;
using AddUser.Infrastructure.Handlers.Producers;
using AddUser.Infrastructure.Producers;
using AddUser.Infrastructure.Stores;
using AddUser.Kafka;
using Confluent.Kafka;
using KafkaDemo.Core.Consumers;
using KafkaDemo.Core.Handlers;
using KafkaDemo.Core.Infrastructure;
using KafkaDemo.Core.Producers;
using EventHandler = AddUser.Infrastructure.Handlers.Consumers.EventHandler;

IHost host = Host.CreateDefaultBuilder(args)
    .UseSystemd()
    .UseWindowsService()
    .ConfigureServices((context, services) =>
    {
        services.Configure<ProducerConfig>(context.Configuration.GetSection(nameof(ProducerConfig)));
        services.Configure<ConsumerConfig>(context.Configuration.GetSection(nameof(ConsumerConfig)));
        services.AddScoped<IEventProducer, EventProducer>();
        services.AddScoped<IEventStore, EventStore>();
        
        services.AddScoped<IEventSourcingHandler<AddUserAggregate>, EventSourcingHandler>();
        services.AddScoped<ICommandHandler, CommandHandler>();
        
        var commandHandler = services.BuildServiceProvider().GetRequiredService<ICommandHandler>();
        
        var dispatcher = new CommandDispatcher();
        dispatcher.RegisterHandler<NewAuthUserAddedCommand>(commandHandler.HandleAsync);
        services.AddSingleton<ICommandDispatcher>(_ => dispatcher);

        services.AddScoped<IEventHandler, EventHandler>();
        services.AddScoped<IEventConsumer, EventConsumer>();
        services.AddHostedService<ConsumerHostedService>();

    })
    .Build();

await host.RunAsync();
