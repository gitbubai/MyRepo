﻿namespace KafkaDemo.Core.Exceptions
{
    public class ConcurrencyException : Exception
    {

    }
}
