﻿using KafkaDemo.Core.Commands;

namespace AddUser.Domain.Commands
{
    public class NewUserAddedCommand : BaseCommand
    {
        public string Email { get; set; }
        public string Name { get; set; }
    }
}
