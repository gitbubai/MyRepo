﻿using AddUser.Domain.Commands;
using AddUser.Domain.Events;
using AddUser.Domain.Topics;
using KafkaDemo.Core.Infrastructure;
using Microsoft.Extensions.Logging;

namespace AddUser.Infrastructure.Handlers.Consumers
{
    public class EventHandler : IEventHandler
    {
        private readonly ILogger<EventHandler> _logger;
        private readonly ICommandDispatcher _commandDispatcher;

        public EventHandler(ILogger<EventHandler> logger, ICommandDispatcher commandDispatcher)
        {
            _logger = logger;
            _commandDispatcher = commandDispatcher;
        }

        public async Task On(NewUserAddedEvent @event)
        {
            _logger.LogInformation($"AddUser Kafka service consumed {nameof(NewUserAddedEvent)} event, User Id: {@event.UserId}");
            NewAuthUserAddedCommand command = new NewAuthUserAddedCommand { Id= Guid.NewGuid(), UserId=@event.UserId, Name=@event.Name, Email=@event.Email};
            _logger.LogInformation($"AddUser Kafka service publishing NewAuthUserAdded event, User Id: {@event.UserId}");
            await _commandDispatcher.SendAsync(command,KafkaTopics.TheAuthTopic);
        }
    }
}
