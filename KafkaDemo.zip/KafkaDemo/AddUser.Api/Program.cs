using AddUser.Domain.Aggregates;
using AddUser.Domain.Commands;
using AddUser.Infrastructure.Dispatchers;
using AddUser.Infrastructure.Handlers.Commands;
using AddUser.Infrastructure.Handlers.Producers;
using AddUser.Infrastructure.Producers;
using AddUser.Infrastructure.Stores;
using Confluent.Kafka;
using KafkaDemo.Core.Handlers;
using KafkaDemo.Core.Infrastructure;
using KafkaDemo.Core.Producers;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<ProducerConfig>(builder.Configuration.GetSection(nameof(ProducerConfig)));
// Add services to the container.
//builder.Services.AddScoped<IEventStoreRepository, EventStoreRepository>();
builder.Services.AddScoped<IEventProducer, EventProducer>();
builder.Services.AddScoped<IEventStore, EventStore>();

builder.Services.AddScoped<IEventSourcingHandler<AddUserAggregate>, EventSourcingHandler>();
builder.Services.AddScoped<ICommandHandler, CommandHandler>();

var commandHandler = builder.Services.BuildServiceProvider().GetRequiredService<ICommandHandler>();

var dispatcher = new CommandDispatcher();
dispatcher.RegisterHandler<NewUserAddedCommand>(commandHandler.HandleAsync);
builder.Services.AddSingleton<ICommandDispatcher>(_ => dispatcher);


builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
