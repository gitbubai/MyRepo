﻿using AddUser.Domain.Commands;

namespace AddUser.Infrastructure.Handlers.Commands
{
    public interface ICommandHandler
    {
        Task HandleAsync(NewUserAddedCommand command, string topic);
        Task HandleAsync(NewAuthUserAddedCommand command, string topic);
    }
}
